# site-shell.zip — placeholder

This is a placeholder for the real Next.js starter shell archive described in
TEMPLATES-BUILDS/00-Next.js-Shell.md.

Replace this zip with an actual export of the shell repo when one exists:

    cd <shell-repo>
    git archive --format=zip -o site-shell.zip HEAD

Keep it in sync with TEMPLATES-BUILDS/01-Design-System.md and
Assets/design-tokens.json whenever the shell's structure changes.
